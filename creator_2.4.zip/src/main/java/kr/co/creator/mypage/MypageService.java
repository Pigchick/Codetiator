package kr.co.creator.mypage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MypageService {

	@Autowired
	MypageDAO dao;

	public void my_dashboard() {
		dao.my_dashboard();
	}
}//class