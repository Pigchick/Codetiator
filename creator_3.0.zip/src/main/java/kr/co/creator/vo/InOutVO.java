package kr.co.creator.vo;

// 투자자입출금
public class InOutVO {
	private int in_out_num;			// 입출금번호
	private String input_history;	// 입금내역
	private String output_history;	// 출금내역
	
	private int account_num;		// (참조)계좌순번
	
	public InOutVO() {}	//constructor
	public InOutVO(int in_out_num, String input_history, String output_history, int account_num) {
		this.in_out_num = in_out_num;
		this.input_history = input_history;
		this.output_history = output_history;
		
		this.account_num = account_num;
	}//constructor
	
	public int getIn_out_num() {
		return in_out_num;
	}
	public void setIn_out_num(int in_out_num) {
		this.in_out_num = in_out_num;
	}//in_out_num
	
	public String getInput_history() {
		return input_history;
	}
	public void setInput_history(String input_history) {
		this.input_history = input_history;
	}//input_history
	
	public String getOutput_history() {
		return output_history;
	}
	public void setOutput_history(String output_history) {
		this.output_history = output_history;
	}//output_history
	
	
	//참조
	public int getAccount_num() {
		return account_num;
	}
	public void setAccount_num(int account_num) {
		this.account_num = account_num;
	}//account_num
}//class
