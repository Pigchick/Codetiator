package kr.co.creator.login;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

}