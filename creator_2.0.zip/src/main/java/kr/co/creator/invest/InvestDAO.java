package kr.co.creator.invest;

import org.springframework.stereotype.Repository;

@Repository
public class InvestDAO {

}