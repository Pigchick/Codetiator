package kr.co.creator.invest;

import org.springframework.stereotype.Service;

@Service
public class InvestService {

}