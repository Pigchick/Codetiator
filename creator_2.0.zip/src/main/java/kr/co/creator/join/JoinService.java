package kr.co.creator.join;

import org.springframework.stereotype.Service;

@Service
public class JoinService {

}