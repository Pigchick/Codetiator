package kr.co.creator.join;

import org.springframework.stereotype.Repository;

@Repository
public class JoinDAO {

}