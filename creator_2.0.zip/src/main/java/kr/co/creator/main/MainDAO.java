package kr.co.creator.main;

import org.springframework.stereotype.Repository;

@Repository
public class MainDAO {

}