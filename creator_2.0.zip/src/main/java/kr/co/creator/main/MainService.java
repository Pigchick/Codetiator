package kr.co.creator.main;

import org.springframework.stereotype.Service;

@Service
public class MainService {

}