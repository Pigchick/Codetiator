package kr.co.creator.user_management;

import org.springframework.stereotype.Service;

@Service
public class UserManagementService {

}