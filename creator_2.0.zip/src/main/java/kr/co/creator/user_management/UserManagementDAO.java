package kr.co.creator.user_management;

import org.springframework.stereotype.Repository;

@Repository
public class UserManagementDAO {

}