package kr.co.creator.account_management;

import org.springframework.stereotype.Repository;

@Repository
public class AccountListDAO {

}