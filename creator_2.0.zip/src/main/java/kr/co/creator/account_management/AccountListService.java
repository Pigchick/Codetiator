package kr.co.creator.account_management;

import org.springframework.stereotype.Service;

@Service
public class AccountListService {

}