package kr.co.creator.mypage;

import org.springframework.stereotype.Service;

@Service
public class MypageService {

}