package kr.co.creator.support;

import org.springframework.stereotype.Repository;

@Repository
public class SupportDAO {

}