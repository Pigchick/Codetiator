package kr.co.creator.project_management;

import org.springframework.stereotype.Service;

@Service
public class ProjectManagementService {

}