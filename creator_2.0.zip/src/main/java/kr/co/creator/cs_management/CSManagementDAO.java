package kr.co.creator.cs_management;

import org.springframework.stereotype.Repository;

@Repository
public class CSManagementDAO {

}