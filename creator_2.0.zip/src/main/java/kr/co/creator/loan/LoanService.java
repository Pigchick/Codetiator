package kr.co.creator.loan;

import org.springframework.stereotype.Service;

@Service
public class LoanService {

}