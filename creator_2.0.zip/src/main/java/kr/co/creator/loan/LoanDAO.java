package kr.co.creator.loan;

import org.springframework.stereotype.Repository;

@Repository
public class LoanDAO {

}