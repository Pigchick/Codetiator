package kr.co.creator.join;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class JoinDAO {
	
	@Autowired
	SqlSession sqlSession;

	public void join() {
		sqlSession.selectList("JoinMapper.");
	}
}//class