package kr.co.creator.loan;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoanController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoanController.class);
	
	@Autowired
	LoanService service;
	
	@RequestMapping(value = "/loan", method = RequestMethod.GET)
	public String loan() {
		logger.info("loan");
		
		service.loan();
		
		return "loan/loan";
	}
	
	@RequestMapping(value = "/loan_guide", method = RequestMethod.GET)
	public String loan_guide() {
		logger.info("loan_guide");
		
		return "loan/loan_guide";
	}
}//class