package kr.co.creator.mypage;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MypageDAO {
	
	@Autowired
	SqlSession sqlSession;

	public void my_dashboard() {
		// sqlSession.selectList("MypageMapper.");
	}
}//class