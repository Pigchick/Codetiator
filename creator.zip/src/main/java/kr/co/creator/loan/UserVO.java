package kr.co.creator.loan;

import java.util.Date;

public class UserVO {
	
	private String user_num;
	private String email;
	private String user_password;
	private String user_name;
	private int chk_receive_email;
	private String phone;
	private String addr;
	private Date join_date;
	private String phone_key;
	private String login_time;
	
	public String getUser_num() {
		return user_num;
	}
	public void setUser_num(String user_num) {
		this.user_num = user_num;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getChk_receive_email() {
		return chk_receive_email;
	}
	public void setChk_receive_email(int chk_receive_email) {
		this.chk_receive_email = chk_receive_email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Date getJoin_date() {
		return join_date;
	}
	public void setJoin_date(Date join_date) {
		this.join_date = join_date;
	}
	public String getPhone_key() {
		return phone_key;
	}
	public void setPhone_key(String phone_key) {
		this.phone_key = phone_key;
	}
	public String getLogin_time() {
		return login_time;
	}
	public void setLogin_time(String login_time) {
		this.login_time = login_time;
	}

}
